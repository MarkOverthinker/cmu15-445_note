sh zip1.sh;
sh zip2.sh;
sh zip3.sh;
sh zip4.sh;

